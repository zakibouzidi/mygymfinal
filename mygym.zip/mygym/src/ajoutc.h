#include <gtk/gtk.h>
#include "callbacks.h"
#include "support.h"
#include "interface.h"
#include "loginc.h"
#include <string.h>
#include <stdio.h>

typedef struct
{
  char num[50];
  char nom[50];
  char jour[50];
  char heure[50]

}cours;
void ajouter_personne(cours s);
void afficher_cours(GtkWidget *liste);
void supprimer(char num[],int n);
void modifier(cours s);
