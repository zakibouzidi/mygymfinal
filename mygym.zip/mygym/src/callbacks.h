#include <gtk/gtk.h>


void
on_log_coach_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_not_coach_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_reg_coach_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_gst_sc_coach_clicked                (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_ajout_cs_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_aff_cs_clicked                      (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_rt1_clicked                         (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_annuler_cs_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_quit_coach_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_logout_coach_clicked                (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_rt2_clicked                         (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_mod_cs_clicked                      (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_sup_cs_clicked                      (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_mod1_cs_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_ret_reg_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);
