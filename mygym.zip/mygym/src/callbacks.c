#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "loginc.c"
#include <stdio.h>
#include <string.h>
#include "ajoutc.c"


void
on_log_coach_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

  int n=150,check = -1;
     char b[70]="HELLO Mr/Ms ";
     char c[50]="username ou password incorrect";
     GtkWidget *input1;
     GtkWidget *input2;
     GtkWidget *output1;
     GtkWidget *output2;
     GtkWidget *coach2;
     GtkWidget *coach1;
     

     coach2=create_coach2();
     input1=lookup_widget(objet_graphique, "entry1");
     input2=lookup_widget(objet_graphique, "entry2");
     output1=lookup_widget(objet_graphique, "label28");
     coach1=lookup_widget(objet_graphique,"coach1");
     char nom[20];
     strcpy(nom,gtk_entry_get_text(GTK_ENTRY(input1)));
     char pass[20];
     strcpy(pass,gtk_entry_get_text(GTK_ENTRY(input2)));
     check = check_user(nom,pass,n);
     if (check==0){
      gtk_widget_hide(coach1);
     strcat(b,nom);
     gtk_widget_show(coach2);
     output2=lookup_widget(coach2, "hello");
     gtk_label_set_text(GTK_LABEL(output2),b);
     }else{
     gtk_label_set_text(GTK_LABEL(output1),c);
     }

}


void
on_not_coach_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
}



void
on_reg_coach_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *coach2;
  GtkWidget *coach6;
  coach6=create_coach6();
  coach2=lookup_widget(objet_graphique,"coach2");
  gtk_widget_hide(coach2);
  gtk_widget_show(coach6);
}


void
on_gst_sc_coach_clicked                (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
 GtkWidget *coach3;
  GtkWidget *coach2;
  coach3=create_coach3();
  coach2=lookup_widget(objet_graphique,"coach2");
  gtk_widget_hide(coach2);
  gtk_widget_show(coach3);
}


void
on_ajout_cs_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
char num[50];char nom[50]; char jour[50];char heure[50];
  GtkWidget *input1;
  GtkWidget * input2;
  GtkWidget *input3;
  GtkWidget *input4;
  GtkWidget *coach3;
  GtkWidget*output; 
  coach3=lookup_widget(objet_graphique,"coach3");
  FILE *f;
char c[]="seance ajoutée";
output=lookup_widget(objet_graphique,"label34");

input1=lookup_widget(objet_graphique,"entry3");
input2=lookup_widget(objet_graphique,"comboboxentry2");
input3=lookup_widget(objet_graphique,"comboboxentry1");
input4=lookup_widget(objet_graphique,"comboboxentry3");
strcpy(num,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(nom,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input2)));
strcpy(jour,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input3)));
strcpy(heure,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input4)));
f=fopen("/home/zack/mygym/src/cours.txt","a+");
if(f!=NULL)
{
  fprintf(f,"%s %s %s %s\n",num,nom,jour,heure);
  fclose(f);
  gtk_label_set_text(GTK_LABEL(output),c);
}


}


void
on_aff_cs_clicked                      (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *coach3;
GtkWidget *coach4;
GtkWidget *treeview1;
coach3=lookup_widget(objet_graphique,"coach3");
gtk_widget_destroy(coach3);
coach4=lookup_widget(objet_graphique,"coach4");
coach4=create_coach4();
gtk_widget_show(coach4);
treeview1=lookup_widget(coach4,"treeview1");
afficher_cours(treeview1);
}


void
on_rt1_clicked                         (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
  GtkWidget *coach3;
  GtkWidget *coach2;
  coach2=create_coach2();
  coach3=lookup_widget(objet_graphique,"coach3");
  gtk_widget_hide(coach3);
  gtk_widget_show(coach2);
}


void
on_annuler_cs_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
 GtkWidget *coach5;
  GtkWidget *coach4;
  GtkWidget *treeview1;
  coach4=create_coach4();
  coach5=lookup_widget(objet_graphique,"coach5");
  gtk_widget_hide(coach5);
  gtk_widget_show(coach4);
treeview1=lookup_widget(coach4,"treeview1");
afficher_cours(treeview1);

}


void
on_quit_coach_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
gtk_main_quit();
}


void
on_logout_coach_clicked                (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
  GtkWidget *coach1;
  GtkWidget *coach2;
  coach1=create_coach1();
  coach2=lookup_widget(objet_graphique,"coach2");
  gtk_widget_hide(coach2);
  gtk_widget_show(coach1);
}


void
on_rt2_clicked                         (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
 GtkWidget *coach3;
  GtkWidget *coach4;
  coach3=create_coach3();
  coach4=lookup_widget(objet_graphique,"coach4");
  gtk_widget_hide(coach4);
  gtk_widget_show(coach3);
}


void
on_mod_cs_clicked                      (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
char num[50];
  cours s;
  FILE*f;
  GtkWidget *input;
  GtkWidget *coach4;
  GtkWidget *coach5;
  GtkWidget *output1;
  GtkWidget *output2;
  GtkWidget *output3;
  GtkWidget *output4;




  input=lookup_widget(objet_graphique,"entry4");
  strcpy(num,gtk_entry_get_text(GTK_ENTRY(input)));
  coach5=create_coach5();
  coach4=lookup_widget(objet_graphique,"coach4");
  gtk_widget_hide(coach4);
  gtk_widget_show(coach5);
  output1=lookup_widget(coach5,"entry6");
  output2=lookup_widget(coach5,"comboboxentry4");
  output3=lookup_widget(coach5,"comboboxentry5");
  output4=lookup_widget(coach5,"comboboxentry6");
  f=fopen("cours.txt","a+");
  if(f!=NULL)
  {
    while(fscanf(f,"%s %s %s %s\n",s.num,s.nom,s.jour,s.heure)!=EOF)
    {
      if(strcmp(num,s.num)==0)
      {
        gtk_entry_set_text(GTK_ENTRY(output1),s.num);
        gtk_entry_set_text(GTK_ENTRY(output2),s.nom);
        gtk_entry_set_text(GTK_ENTRY(output3),s.jour);
        gtk_entry_set_text(GTK_ENTRY(output4),s.heure);
        
      }
    }
    fclose(f);
}

}


void
on_sup_cs_clicked                      (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
  GtkWidget *input;
  GtkWidget *treeview1;
  GtkWidget *coach4;
  GtkWidget *output;
  char c[]="seance supprimée";
  output=lookup_widget(objet_graphique,"label20");
  coach4=(objet_graphique,"coach4");
  int  n=9;
  char num[9];
  input=lookup_widget(objet_graphique,"entry5");
  strcpy(num,gtk_entry_get_text(GTK_ENTRY(input)));
  supprimer(num,n);
  treeview1=lookup_widget(objet_graphique,"treeview1");
  afficher_cours(treeview1);
  gtk_label_set_text(GTK_LABEL(output),c);
}


void
on_mod1_cs_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
  GtkWidget*input1;
  GtkWidget*input2;
  GtkWidget*input3;
  GtkWidget*input4;
  GtkWidget*output;
  FILE*f;
  char c[]="modification terminee";
  output=lookup_widget(objet_graphique,"label23");
  cours s;
  input1=lookup_widget(objet_graphique,"entry6");
  input2=lookup_widget(objet_graphique,"comboboxentry4");
  input3=lookup_widget(objet_graphique,"comboboxentry5");
  input4=lookup_widget(objet_graphique,"comboboxentry6");
  strcpy(s.num,gtk_entry_get_text(GTK_ENTRY(input1)));
  strcpy(s.nom,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input2)));
  strcpy(s.jour,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input3)));
  strcpy(s.heure,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input4)));
  modifier(s);
  gtk_label_set_text(GTK_LABEL(output),c);

}


void
on_ret_reg_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *coach2;
  GtkWidget *coach6;
  coach2=create_coach2();
  coach6=lookup_widget(objet_graphique,"coach6");
  gtk_widget_hide(coach6);
  gtk_widget_show(coach2);
}

